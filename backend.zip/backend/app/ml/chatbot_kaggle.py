# app/ml/chatbot_kaggle.py

from __future__ import annotations

from pathlib import Path
import pickle
import numpy as np
import pandas as pd
import re

from app.core.config import settings

# ---------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------
DATA_DIR = Path(settings.DATA_DIR)
print("Chatbot DATA_DIR =", DATA_DIR)

MODEL_PATH = DATA_DIR / "chatbot_model.pkl"
VECTORIZER_PATH = DATA_DIR / "vectorizer.pkl"
TFIDF_PATH = DATA_DIR / "tfidf_matrix.npy"   # optional (not required here)
CSV_PATH = DATA_DIR / "cleaned_dataset.csv"


class FAQChatbot:
    """
    Hybrid GlowUP assistant:

    - For support questions (orders, returns, payments, shipping…):
      uses sklearn LogisticRegression + TF-IDF trained on Kaggle.

    - For style / outfit questions:
      uses rule-based GlowUP stylist replies to suggest outfits.
    """

    def __init__(self) -> None:
        # --- load model + vectorizer -----------------------------------
        with open(MODEL_PATH, "rb") as f:
            self.model = pickle.load(f)

        with open(VECTORIZER_PATH, "rb") as f:
            self.vectorizer = pickle.load(f)

        # --- load CSV ---------------------------------------------------
        if not CSV_PATH.exists():
            raise FileNotFoundError(f"CSV file not found at {CSV_PATH}")

        self.df = pd.read_csv(CSV_PATH)

        if "label" not in self.df.columns:
            raise ValueError("cleaned_dataset.csv must have a 'label' column")
        if "text" not in self.df.columns:
            raise ValueError("cleaned_dataset.csv must have a 'text' column")

        # Build a map: label -> representative FAQ question text
        self.label_to_question: dict[str, str] = {}
        for _, row in self.df.iterrows():
            label = str(row["label"])
            if label not in self.label_to_question:
                self.label_to_question[label] = str(row["text"])

        # Optional: load TF-IDF matrix if you want similarity later
        if TFIDF_PATH.exists():
            self.tfidf_matrix = np.load(TFIDF_PATH)
        else:
            self.tfidf_matrix = None

    # ------------------------------------------------------------------
    # SUPPORT SIDE  (Kaggle classifier + templates)
    # ------------------------------------------------------------------
    def _looks_like_support(self, text: str) -> bool:
        """
        Quick keyword check: is this about order/support,
        or about styling & outfits?
        """
        text = text.lower()
        support_keywords = [
            "order", "track", "tracking", "delivery", "shipping",
            "cancel", "canceled", "cancelled", "refund", "return",
            "payment", "card", "credit", "debit", "cash on delivery",
            "account", "login", "password", "email change",
            "where is my order", "status"
        ]
        return any(k in text for k in support_keywords)

    def _topic_from_label(self, label: str) -> str:
        """
        Guess a topic string ('order_status', 'cancel', 'return', ...)
        from the representative FAQ question for this label.
        """
        q = self.label_to_question.get(str(label), "").lower()

        if "cancel" in q:
            return "cancel"
        if ("where is my order" in q or "where's my order" in q or
                "track" in q or "tracking" in q):
            return "order_status"
        if "return" in q or "refund" in q:
            return "return"
        if "exchange" in q or "size" in q or "fit" in q:
            return "size_exchange"
        if "shipping" in q or "delivery" in q:
            return "shipping"
        if "payment" in q or "card" in q or "credit" in q or "debit" in q:
            return "payment"
        if "account" in q or "password" in q or "login" in q:
            return "account"

        return "other"

    def _support_template_answer(self, topic: str) -> str:
        """
        Map a high-level topic to a GlowUP-style **support** answer.
        """
        if topic == "order_status":
            return (
                "You can track your order from **Account → Orders** in GlowUP, "
                "or by using the tracking link we sent to your email. "
                "If the status hasn’t updated for a while, it may still be with the courier."
            )

        if topic == "cancel":
            return (
                "If you accidentally cancelled your order, it usually can’t be restored once "
                "the cancellation is confirmed. You can place a new order with the same items, "
                "and if you’re unsure about the status, contact GlowUP support with your order number."
            )

        if topic == "return":
            return (
                "You can request a return from your **Orders** page. Make sure items still have "
                "their tags and are in the original condition. Once your return is approved and "
                "received, your refund will be processed back to your original payment method."
            )

        if topic == "size_exchange":
            return (
                "For size issues, check our **Size Guide** on each product page. "
                "If the item doesn’t fit, you can usually request an exchange or return, "
                "depending on availability and policy in your region."
            )

        if topic == "shipping":
            return (
                "Standard shipping typically takes **3–5 business days**, depending on your city. "
                "During sales or holidays, it can take a bit longer. You can always see the latest "
                "estimate on your tracking page."
            )

        if topic == "payment":
            return (
                "GlowUP accepts common payment methods such as credit/debit cards and sometimes "
                "cash-on-delivery, depending on your region. If a payment fails, double-check your "
                "card details, available balance, and try again or use another method."
            )

        if topic == "account":
            return (
                "For account issues, try resetting your password from the login screen. "
                "If you still can’t sign in, contact support using the email you registered with "
                "so we can verify your account safely."
            )

        # Fallback generic support answer
        return (
            "I’ve matched your question to a GlowUP help topic. 🌸\n\n"
            "Right now I can answer general things about orders, returns, shipping, sizes, "
            "and payments. If this doesn’t solve it, you can contact support from your "
            "**Account → Help** page for more detailed assistance."
        )

    def _handle_support(self, user_message: str) -> str:
        """Run the Kaggle classifier + template mapping."""
        X = self.vectorizer.transform([user_message])
        label = self.model.predict(X)[0]
        topic = self._topic_from_label(str(label))
        return self._support_template_answer(topic)

    # ------------------------------------------------------------------
    # STYLIST SIDE  (outfit suggestions)
    # ------------------------------------------------------------------
    def _style_suggestion(self, user_message: str) -> str:
        """
        Rule-based GlowUP stylist that suggests outfits
        from the user’s free-text request.
        """
        text = user_message.lower()

        # --- detect body shape ------------------------------------------
        body_shape = None
        for shape in [
            "hourglass", "pear", "apple",
            "rectangle", "inverted triangle", "triangle"
        ]:
            if shape in text:
                body_shape = shape
                break

        # --- detect fit preference --------------------------------------
        relaxed_fit = any(w in text for w in ["relaxed", "loose", "oversized"])
        fitted_fit = any(w in text for w in ["fitted", "bodycon", "slim"])

        # --- detect style vibe ------------------------------------------
        style_vibe = None
        for vibe in [
            "fashion-forward", "fashion forward", "trendy",
            "minimal", "classic", "sporty", "casual", "elegant",
            "streetwear"
        ]:
            if vibe in text:
                style_vibe = vibe
                break

        # --- detect skin tone -------------------------------------------
        skin_tone = None
        skin_patterns = [
            "fair", "light", "medium", "tan", "deep",
            "warm", "cool", "neutral", "olive"
        ]
        for st in skin_patterns:
            if st in text:
                # catch things like "medium/cool"
                skin_tone = st
                # special: medium/cool, medium warm, etc.
                if "medium" in text and "cool" in text:
                    skin_tone = "medium/cool"
                elif "medium" in text and "warm" in text:
                    skin_tone = "medium/warm"
                break

        # --- detect occasion --------------------------------------------
        occasion = "everyday"
        if any(w in text for w in ["wedding", "engagement"]):
            occasion = "wedding"
        elif any(w in text for w in ["party", "birthday", "celebration"]):
            occasion = "party"
        elif any(w in text for w in ["graduation"]):
            occasion = "graduation"
        elif any(w in text for w in ["office", "interview", "meeting", "work"]):
            occasion = "office"
        elif any(w in text for w in ["university", "college", "campus", "class"]):
            occasion = "university"
        elif any(w in text for w in ["travel", "airport", "flight"]):
            occasion = "travel"
        elif any(w in text for w in ["beach", "resort"]):
            occasion = "beach"

        # --- detect weather ---------------------------------------------
        weather = "mild"
        if any(w in text for w in ["hot", "summer", "sunny", "heat"]):
            weather = "hot"
        elif any(w in text for w in ["cold", "winter", "rain", "raining", "rainy", "windy"]):
            weather = "cold"

        # --- detect modest / hijab hints --------------------------------
        modest = any(w in text for w in ["modest", "hijab", "abaya", "long", "not tight"])

        # --- detect color preferences -----------------------------------
        colors = []
        color_words = [
            "black", "white", "beige", "brown", "blue", "navy",
            "pink", "green", "olive", "cream", "neutral", "grey", "gray"
        ]
        for c in color_words:
            if c in text:
                colors.append(c)
        colors = list(dict.fromkeys(colors))  # unique order

        # default neutrals if user didn't specify
        if colors:
            color_phrase = ", ".join(colors)
        else:
            color_phrase = "neutral tones (beige, cream, soft brown)"

        # for cool skin tones, hint towards cool neutrals
        if skin_tone and "cool" in skin_tone and not colors:
            color_phrase = "cool neutrals like black, charcoal, and soft white"

        # --- build suggestion based on rules ----------------------------
        base_intro = "Here’s a GlowUP outfit idea for you 🌸\n\n"
        pieces = []

        # TOP & BOTTOM based on occasion + weather
        if occasion in ["office", "university", "travel", "everyday"]:
            sleeve = "long-sleeve" if modest else "flowy"
            if weather == "hot":
                top = f"a lightweight {sleeve} blouse in {color_phrase}"
                bottom = "high-waisted wide-leg trousers or a modest A-line skirt"
            elif weather == "cold":
                top = f"a fine-knit sweater layered over a shirt in {color_phrase}"
                bottom = "straight-cut trousers or wide-leg jeans"
            else:
                # special: relaxed fit wording
                fit_word = "relaxed " if relaxed_fit else ""
                top = f"a {fit_word}shirt or blouse in {color_phrase}"
                bottom = "straight jeans or tailored trousers"
        elif occasion in ["party", "graduation"]:
            if modest:
                top = "a satin long-sleeve blouse with subtle shine"
                bottom = "a maxi pleated skirt or wide-leg tailored pants"
            else:
                top = "a fitted top with a little shimmer"
                bottom = "wide-leg trousers or a midi skirt"
        elif occasion == "wedding":
            top = "a flowy chiffon dress with long sleeves in soft pastel " + ("or "+color_phrase if colors else "")
            bottom = ""
        elif occasion == "beach":
            top = "a breezy linen shirt in "+color_phrase
            bottom = "wide-leg pants or a long flowy skirt over a modest swimsuit"
        else:
            top = "a soft tee or blouse in "+color_phrase
            bottom = "relaxed jeans or a midi skirt"

        if top:
            pieces.append(f"• **Top:** {top}.")
        if bottom:
            pieces.append(f"• **Bottom:** {bottom}.")

        # Outer layer
        if weather == "cold":
            outer = "an oversized blazer or long trench coat in a neutral color"
        else:
            outer = "a light kimono, cardigan, or cropped blazer if you need extra coverage"
        if modest:
            outer += " (choose something that covers the hips for a more modest silhouette)"
        pieces.append(f"• **Layer:** {outer}.")

        # Shoes
        if occasion in ["office", "graduation", "wedding", "party"]:
            shoes = "low-heel pumps or elegant block-heel sandals"
        elif occasion == "travel":
            shoes = "comfortable white sneakers or cushioned loafers"
        else:
            shoes = "clean white sneakers, loafers, or simple sandals"
        pieces.append(f"• **Shoes:** {shoes}.")

        # Accessories & hijab styling
        acc = "• **Accessories:** small gold jewelry, a structured bag, and a simple watch."
        if skin_tone and "cool" in skin_tone:
            acc += " Silver or white-gold details will look especially good on your medium/cool undertone."
        if modest:
            acc += (
                "\n• **Hijab idea:** choose a chiffon or cotton hijab in a tone close to your top, "
                "wrap it in a soft drape style to keep the look elegant but comfortable."
            )
        pieces.append(acc)

        # Extra explanation tying back to profile-like text
        extra_bits = []
        if body_shape == "hourglass":
            extra_bits.append(
                "This combo flatters an **hourglass** body by softly defining the waist "
                "while keeping everything comfortable and not too tight."
            )
        if relaxed_fit:
            extra_bits.append(
                "Pieces are kept **relaxed-fit**, so you get coverage and ease of movement without feeling restricted."
            )
        if style_vibe and ("fashion-forward" in style_vibe or "trendy" in style_vibe):
            extra_bits.append(
                "Details like the layering and accessories keep the look **trendy / fashion-forward**."
            )

        extra_text = ""
        if extra_bits:
            extra_text = "\n\n" + " ".join(extra_bits)

        closing = (
            "\n\nTell me the exact **occasion** (university day, office, wedding, travel…) "
            "or if you want a different vibe (sporty, minimal, extra glam) and I’ll tweak the outfit for you. ✨"
        )

        return base_intro + "\n".join(pieces) + extra_text + closing

    # ------------------------------------------------------------------
    # Public method used by the FastAPI router
    # ------------------------------------------------------------------
    def answer(self, user_message: str) -> str:
        """
        Main entry point: detect support vs styling.
        """
        if not user_message or not user_message.strip():
            return "Please type your question so I can help you 🌸"

        text = user_message.lower()

        # 1) Support questions → Kaggle model + templates
        if self._looks_like_support(text):
            return self._handle_support(user_message)

        # 2) Otherwise → stylist mode
        return self._style_suggestion(user_message)


# ----------------------------------------------------------------------
# Global singleton
# ----------------------------------------------------------------------

_chatbot_instance: FAQChatbot | None = None


def get_chatbot() -> FAQChatbot:
    """
    Lazy-load singleton so the model is loaded only once.
    """
    global _chatbot_instance
    if _chatbot_instance is None:
        _chatbot_instance = FAQChatbot()
    return _chatbot_instance
