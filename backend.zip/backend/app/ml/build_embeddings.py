# app/ml/build_embeddings.py

import os
from pathlib import Path
from typing import List, Tuple

import numpy as np
import pandas as pd
from tqdm import tqdm
from PIL import Image
import requests
import torch
from sentence_transformers import SentenceTransformer
from transformers import CLIPProcessor, CLIPModel

from app.core.config import settings
from app.core.db import SessionLocal
from app.models.models import Product


# -------------------------------
# Paths
# -------------------------------
BACKEND_ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = Path(settings.DATA_DIR)

DATA_DIR.mkdir(parents=True, exist_ok=True)

IMG_FEATS_PATH = DATA_DIR / "fashion_image_features.npy"
TXT_FEATS_PATH = DATA_DIR / "fashion_text_features.npy"
META_CSV_PATH = DATA_DIR / "fashion_metadata.csv"


# -------------------------------
# Models
# -------------------------------

# Text model (for title + description)
TEXT_MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
text_model = SentenceTransformer(TEXT_MODEL_NAME)

# Image model (CLIP vision encoder)
CLIP_MODEL_NAME = "openai/clip-vit-base-patch32"
clip_model = CLIPModel.from_pretrained(CLIP_MODEL_NAME)
clip_processor = CLIPProcessor.from_pretrained(CLIP_MODEL_NAME)
clip_model.eval()


# -------------------------------
# Helper functions
# -------------------------------

def _normalize(vec: np.ndarray) -> np.ndarray:
    """L2-normalize a vector."""
    norm = np.linalg.norm(vec)
    if norm == 0:
        return vec
    return vec / norm


def load_image_from_product(image_url: str) -> Image.Image | None:
    """
    Try to load an image for a product.
    Supports:
      - Absolute URLs (http://, https://)
      - Relative paths like /static/... or static/...
    Returns a PIL Image or None if it fails.
    """
    if not image_url:
        return None

    image_url = image_url.strip()

    # Case 1: HTTP URL
    if image_url.startswith("http://") or image_url.startswith("https://"):
        try:
            resp = requests.get(image_url, timeout=10, stream=True)
            resp.raise_for_status()
            img = Image.open(resp.raw).convert("RGB")
            return img
        except Exception:
            return None

    # Case 2: relative path -> map to backend filesystem
    # e.g. "/static/imgs/foo.jpg" or "static/imgs/foo.jpg"
    rel = image_url.lstrip("/")
    local_path = BACKEND_ROOT / rel

    if local_path.exists():
        try:
            img = Image.open(local_path).convert("RGB")
            return img
        except Exception:
            return None

    return None


def embed_image(img: Image.Image) -> np.ndarray:
    """
    Compute a CLIP image embedding and return a 1D numpy array.
    """
    inputs = clip_processor(images=img, return_tensors="pt")
    with torch.no_grad():
        feats = clip_model.get_image_features(**inputs)  # [1, d]
    feats = feats[0].cpu().numpy().astype("float32")
    return _normalize(feats)


def embed_text_batch(texts: List[str]) -> np.ndarray:
    """
    Compute sentence embeddings for a list of texts.
    Returns array [N, D].
    """
    if not texts:
        return np.zeros((0, 384), dtype="float32")  # MiniLM default dim = 384
    embs = text_model.encode(
        texts,
        batch_size=32,
        show_progress_bar=True,
        convert_to_numpy=True,
        normalize_embeddings=True,
    )
    return embs.astype("float32")


# -------------------------------
# Main pipeline
# -------------------------------

def build_embeddings() -> Tuple[np.ndarray, np.ndarray, pd.DataFrame]:
    """
    1) Fetch products from DB
    2) Build text embeddings
    3) Build image embeddings (CLIP). If image fails, fallback to text embedding.
    4) Save everything to DATA_DIR.
    """
    db = SessionLocal()
    try:
        # Get all active products (adjust filter if your field is different)
        products: List[Product] = (
            db.query(Product)
            .filter(Product.is_active == True)  # type: ignore
            .order_by(Product.id)
            .all()
        )
    finally:
        db.close()

    if not products:
        print("⚠ No products found in DB. Nothing to embed.")
        return (
            np.zeros((0, 384), dtype="float32"),
            np.zeros((0, 512), dtype="float32"),
            pd.DataFrame(),
        )

    print(f"✅ Found {len(products)} products. Building embeddings...")

    # ----------- Text embeddings -----------
    texts: List[str] = []
    for p in products:
        title = (p.name or "").strip()
        desc = (p.description or "").strip()
        cat = (p.category or "").strip()
        full_text = ". ".join(t for t in [title, desc, cat] if t)
        texts.append(full_text if full_text else title)

    text_embs = embed_text_batch(texts)  # [N, Dt]
    print(f"✅ Text embeddings shape: {text_embs.shape}")

    # ----------- Image embeddings -----------
    img_emb_list: List[np.ndarray] = []
    failed = 0

    for idx, p in enumerate(tqdm(products, desc="Image embeddings")):
        image_url = getattr(p, "image_url", None) or getattr(p, "img_url", None) or ""

        img = load_image_from_product(image_url)
        if img is None:
            # Fallback: reuse text embedding if image not available
            img_emb_list.append(text_embs[idx].copy())
            failed += 1
            continue

        try:
            emb = embed_image(img)
            img_emb_list.append(emb)
        except Exception:
            # If CLIP fails, also fallback to text embedding
            img_emb_list.append(text_embs[idx].copy())
            failed += 1

    img_embs = np.stack(img_emb_list, axis=0)
    print(f"✅ Image embeddings shape: {img_embs.shape}")
    if failed > 0:
        print(f"⚠ {failed} products used text embeddings as fallback (image missing or failed).")

    # ----------- Metadata -----------
    rows = []
    for p in products:
        rows.append(
            {
                "product_id": p.id,
                "sku": str(p.sku).strip(),
                "name": (p.name or "").strip(),
                "category": (p.category or "").strip(),
                "brand": getattr(p, "brand", ""),
                "color": getattr(p, "color", ""),
                "price": float(p.price) if p.price is not None else None,
                "image_url": getattr(p, "image_url", ""),
            }
        )

    meta_df = pd.DataFrame(rows)

    # ----------- Save to disk -----------
    np.save(IMG_FEATS_PATH, img_embs)
    np.save(TXT_FEATS_PATH, text_embs)
    meta_df.to_csv(META_CSV_PATH, index=False)

    print(f"✅ Saved image feats: {IMG_FEATS_PATH}")
    print(f"✅ Saved text feats:  {TXT_FEATS_PATH}")
    print(f"✅ Saved metadata:    {META_CSV_PATH}")

    return img_embs, text_embs, meta_df


if __name__ == "__main__":
    build_embeddings()
