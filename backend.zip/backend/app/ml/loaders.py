# app/ml/loaders.py
import os
from pathlib import Path

import numpy as np
import pandas as pd

from app.core.config import settings

DATA = Path(settings.DATA_DIR)
IMG_FEATS = DATA / "fashion_image_features.npy"
TXT_FEATS = DATA / "fashion_text_features.npy"
META_CSV = DATA / "fashion_metadata.csv"


def get_embeddings():
    """
    Load the 3 embedding files + build SKU → row mapping.
    Always return exactly 4 values.

    Returns:
        img_feats (np.ndarray or None)
        txt_feats (np.ndarray or None)
        meta_df (pd.DataFrame or None)
        sku2row (dict or None)
    """

    if not IMG_FEATS.exists():
        raise FileNotFoundError(f"Missing file: {IMG_FEATS}")
    if not TXT_FEATS.exists():
        raise FileNotFoundError(f"Missing file: {TXT_FEATS}")
    if not META_CSV.exists():
        raise FileNotFoundError(f"Missing file: {META_CSV}")

    img = np.load(IMG_FEATS)
    txt = np.load(TXT_FEATS)
    meta = pd.read_csv(META_CSV)

    sku2row = {
        str(row["sku"]).strip(): idx
        for idx, row in meta.iterrows()
    }

    return img, txt, meta, sku2row
