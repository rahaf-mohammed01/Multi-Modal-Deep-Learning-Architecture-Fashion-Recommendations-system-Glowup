from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from sqlalchemy import String, Integer, Float, ForeignKey, DateTime, Text, Boolean
import datetime as dt
from sqlalchemy import JSON


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    username: Mapped[str | None] = mapped_column(
        String(64),
        unique=True,
        index=True,
        nullable=True,
    )
    password_hash: Mapped[str]
    role: Mapped[str] = mapped_column(String(32), default="customer")
    status: Mapped[str] = mapped_column(String(16), default="active")
    created_at: Mapped[dt.datetime] = mapped_column(default=dt.datetime.utcnow)

    # --- personal info ---
    full_name: Mapped[str | None] = mapped_column(String(128), nullable=True)
    phone: Mapped[str | None] = mapped_column(String(32), nullable=True)
    date_of_birth: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)
    gender: Mapped[str | None] = mapped_column(String(16), nullable=True)

    # --- style profile ---
    fav_color: Mapped[str | None] = mapped_column(String(64), nullable=True)
    skin_tone: Mapped[str | None] = mapped_column(String(64), nullable=True)
    body_shape: Mapped[str | None] = mapped_column(String(64), nullable=True)
    preferred_fit: Mapped[str | None] = mapped_column(String(64), nullable=True)
    style_vibe: Mapped[str | None] = mapped_column(String(64), nullable=True)

    # --- shipping address ---
    street_address: Mapped[str | None] = mapped_column(Text, nullable=True)
    city: Mapped[str | None] = mapped_column(String(128), nullable=True)
    postal_code: Mapped[str | None] = mapped_column(String(32), nullable=True)
    country: Mapped[str | None] = mapped_column(String(64), nullable=True)

    # --- profile picture ---
    profile_picture: Mapped[str | None] = mapped_column(String(512), nullable=True)


class Product(Base):
    __tablename__ = "products"

    id: Mapped[int] = mapped_column(primary_key=True)
    sku: Mapped[str] = mapped_column(String(64), unique=True)
    name: Mapped[str] = mapped_column(String(255))
    description: Mapped[str] = mapped_column(Text)
    category: Mapped[str] = mapped_column(String(64))
    price: Mapped[float]
    image_url: Mapped[str] = mapped_column(String(512))
    brand: Mapped[str] = mapped_column(String(128))
    color: Mapped[str] = mapped_column(String(64))
    size: Mapped[str] = mapped_column(String(32))
    in_stock: Mapped[bool] = mapped_column(default=True)
    available_colors: Mapped[str] = mapped_column(
        Text,
        default="",  # comma-separated: "black,brown,beige"
    )
    available_sizes: Mapped[str] = mapped_column(
        Text,
        default="XS,S,M,L,XL",
    )
    stock: Mapped[int] = mapped_column(Integer, default=0)
    


class Interaction(Base):
    __tablename__ = "interactions"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"))
    event: Mapped[str] = mapped_column(
        String(32)
    )  # view, click, add_to_cart, purchase, like, rating
    value: Mapped[float] = mapped_column(default=0.0)
    text: Mapped[str] = mapped_column(Text, default="")
    ts: Mapped[dt.datetime] = mapped_column(default=dt.datetime.utcnow)


class CartItem(Base):
    __tablename__ = "cart_items"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"))
    qty: Mapped[int] = mapped_column(Integer, default=1)
    color: Mapped[str | None] = mapped_column(String(64), nullable=True)
    size: Mapped[str | None] = mapped_column(String(32), nullable=True)


class Order(Base):
    __tablename__ = "orders"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    total: Mapped[float] = mapped_column(Float, default=0.0)
    created_at: Mapped[dt.datetime] = mapped_column(default=dt.datetime.utcnow)
    buyer_name: Mapped[str] = mapped_column(String(128), default="")
    buyer_email: Mapped[str] = mapped_column(String(255), default="")
    buyer_phone: Mapped[str] = mapped_column(String(32), default="")
    buyer_address: Mapped[str] = mapped_column(Text, default="")
    payment_method: Mapped[str] = mapped_column(String(32), default="card")
    tax: Mapped[float] = mapped_column(Float, default=0.0)
    final_total: Mapped[float] = mapped_column(Float, default=0.0)
    status: Mapped[str] = mapped_column(String(16), default="pending")
    refund_date: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)


class OrderItem(Base):
    __tablename__ = "order_items"

    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id"))
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"))
    price: Mapped[float]
    qty: Mapped[int]
    color: Mapped[str | None] = mapped_column(String(64), nullable=True)
    size: Mapped[str | None] = mapped_column(String(32), nullable=True)


class PasswordResetToken(Base):
    __tablename__ = "password_reset_tokens"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    token: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    expires_at: Mapped[dt.datetime]
    used: Mapped[bool] = mapped_column(Boolean, default=False)
