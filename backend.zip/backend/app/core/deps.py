from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer
from jose import jwt, JWTError
from sqlalchemy.orm import Session
from app.core.config import settings
from app.core.db import get_db
from app.models.models import User

bearer = HTTPBearer(auto_error=False)

async def get_current_user(token=Depends(bearer), db: Session = Depends(get_db)) -> User:
    if not token:
        raise HTTPException(401, "Not authenticated")
    try:
        payload = jwt.decode(token.credentials, settings.JWT_SECRET, algorithms=[settings.JWT_ALG])
        if payload.get("scope") != "access":
            raise HTTPException(401, "Invalid token scope")
        uid = int(payload.get("sub"))
    except (JWTError, ValueError):
        raise HTTPException(401, "Invalid token")
    user = db.get(User, uid)
    if not user:
        raise HTTPException(401, "User not found")
    return user

def require_any_role(*roles: str):
    async def _check(user: User = Depends(get_current_user)):
        if user.role not in roles and user.role != "admin":
            raise HTTPException(403, "Insufficient permissions")
        return user
    return _check


