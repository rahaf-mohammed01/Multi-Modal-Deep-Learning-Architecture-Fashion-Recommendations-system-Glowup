from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import List

BASE_DIR = Path(__file__).resolve().parents[2]

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    ENV: str = "dev"
    DATABASE_URL: str = "postgresql+psycopg://glowup:glowup@fashion-db:5432/glowup"
    JWT_SECRET: str = "change-me"
    JWT_ALG: str = "HS256"
    ACCESS_EXPIRES_MIN: int = 30
    REFRESH_EXPIRES_DAYS: int = 7

    # 👇 important: now points to C:\glowup\backend\data on your machine
    DATA_DIR: str = str(BASE_DIR / "data")
    UPLOAD_DIR: str = str(BASE_DIR / "uploaded_data")
    MLFLOW_TRACKING_URI: str = str(BASE_DIR / "data" / "mlruns")

    CORS_ORIGINS: List[str] = ["http://localhost:4200"]


settings = Settings()
