# app/core/security.py

from datetime import datetime, timedelta
from typing import Generator

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, HTTPBearer
from jose import jwt, JWTError
from passlib.context import CryptContext
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.deps import get_db          
from app.models.models import User

# --------------------
# password hashing
# --------------------
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(p: str) -> str:
    return pwd_context.hash(p)


def verify_password(p: str, hashed: str) -> bool:
    try:
        return pwd_context.verify(p, hashed)
    except Exception:
        return False


# --------------------
# token helpers
# --------------------
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")
http_bearer = HTTPBearer(auto_error=False)


def create_token(sub: str, scope: str, minutes: int) -> str:
    now = datetime.utcnow()
    payload = {
        "sub": sub,
        "scope": scope,
        "iat": now,
        "exp": now + timedelta(minutes=minutes),
    }
    return jwt.encode(payload, settings.JWT_SECRET, algorithm=settings.JWT_ALG)


def create_access_token(sub: str, scope: str = "access") -> str:
    return create_token(sub, scope, settings.ACCESS_EXPIRES_MIN)


def create_refresh_token(sub: str, scope: str = "refresh") -> str:
    return create_token(sub, scope, settings.REFRESH_EXPIRES_DAYS * 24 * 60)


# --------------------
# current user helpers
# --------------------
def _credentials_exc() -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )


def _get_user_from_token(token: str, scope: str, db: Session) -> User:
    """Decode JWT, check scope, load active user from DB."""
    try:
        payload = jwt.decode(token, settings.JWT_SECRET, algorithms=[settings.JWT_ALG])
        if payload.get("scope") != scope:
            raise _credentials_exc()
        sub = payload.get("sub")
        user_id = int(sub)
    except (JWTError, ValueError, TypeError):
        raise _credentials_exc()

    user = db.get(User, user_id)
    if not user or user.status != "active":
        raise _credentials_exc()
    return user


def get_current_user(
    db: Session = Depends(get_db),          
    token: str = Depends(oauth2_scheme),
) -> User:
    """Dependency: return the currently-authenticated user."""
    return _get_user_from_token(token, "access", db)
