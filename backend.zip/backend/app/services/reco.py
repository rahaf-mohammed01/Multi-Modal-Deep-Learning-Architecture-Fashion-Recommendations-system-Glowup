# app/services/reco.py
import numpy as np
from typing import Dict, Iterable, List, Tuple, Optional
from sqlalchemy.orm import Session
from sklearn.metrics.pairwise import cosine_similarity

from app.ml.loaders import get_embeddings
from app.models.models import Product, Interaction


EVENT_W = {
    "view": 0.5,
    "click": 0.8,
    "add_to_cart": 1.0,
    "like": 1.0,
    "purchase": 1.5,
    "rating": 1.2,
}


class RecoEngine:
    def __init__(self):
        img, txt, meta, sku2row = get_embeddings()

        self.img = img
        self.txt = txt
        self.meta = meta
        self.sku2row = sku2row

        self.has_embeddings = (
            img is not None
            and meta is not None
            and sku2row is not None
            and len(img) > 0
        )

        # build reverse index for DB queries
        self.idx_to_sku = {i: sku for sku, i in sku2row.items()}
        self.n_items = len(self.idx_to_sku)

    # ---------------------------------------------------------
    # INTERNAL HELPERS
    # ---------------------------------------------------------
    def _visible_only(self, q):
        return q.filter(Product.active == True)

    def _get_emb(self, sku: str) -> Optional[np.ndarray]:
        idx = self.sku2row.get(str(sku).strip())
        if idx is None:
            return None
        return self.img[idx]

    def _build_user_profile(self, db: Session, user_id: int) -> Optional[np.ndarray]:
        interactions = (
            db.query(Interaction)
            .filter(Interaction.user_id == user_id)
            .all()
        )

        if not interactions:
            return None

        profile = np.zeros(self.img.shape[1])
        total_w = 0

        for it in interactions:
            ev = getattr(it, "event_type", None)
            w = EVENT_W.get(ev, 0.5)

            prod = db.query(Product).get(it.product_id)
            if not prod:
                continue

            vec = self._get_emb(prod.sku)
            if vec is None:
                continue

            profile += w * vec
            total_w += w

        if total_w == 0:
            return None

        profile /= total_w
        norm = np.linalg.norm(profile)
        if norm > 0:
            profile /= norm

        return profile

    def _rows_to_products(self, db: Session, rows: Iterable[int]) -> List[Product]:
        skus = [self.idx_to_sku[r] for r in rows if r in self.idx_to_sku]
        products = (
            db.query(Product)
            .filter(Product.sku.in_(skus))
            .all()
        )
        sku_map = {p.sku: p for p in products}
        return [sku_map[s] for s in skus if s in sku_map]

    # ---------------------------------------------------------
    # PUBLIC FUNCTIONS → used by router
    # ---------------------------------------------------------
    def personalized_for_user(
        self,
        db: Session,
        user_id: int,
        k: int = 12,
    ) -> List[Product]:

        base_q = self._visible_only(db.query(Product))

        if not self.has_embeddings:
            return base_q.order_by(Product.id.desc()).limit(k).all()

        profile = self._build_user_profile(db, user_id)

        if profile is None:
            return base_q.order_by(Product.id.desc()).limit(k).all()

        sims = cosine_similarity(profile.reshape(1, -1), self.img)[0]
        top_rows = np.argsort(-sims)[: 5 * k]

        products = self._rows_to_products(db, top_rows)

        seen = set()
        out = []

        for p in products:
            if p.id not in seen:
                seen.add(p.id)
                out.append(p)
                if len(out) == k:
                    break

        return out

    def generate_outfits(
        self,
        db: Session,
        user_id: Optional[int] = None,
        k: int = 4,
    ) -> List[List[Product]]:

        base_q = self._visible_only(db.query(Product))
        items = base_q.order_by(Product.id.desc()).all()

        if not items:
            return []

        looks = []
        idx = 0

        for _ in range(k):
            outfit = items[idx:idx + 4]
            if not outfit:
                break
            looks.append(outfit)
            idx += 4
            if idx >= len(items):
                idx = 0

        return looks
