# app/routers/interactions.py
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.core.deps import get_current_user
from app.models.models import Interaction

router = APIRouter(prefix="/api/interactions", tags=["interactions"])

class LogEvent(BaseModel):
    product_id: int
    event: str        # "view" | "click" | "add_to_cart" | "purchase" | "like" | "rating"
    value: float = 0  # optional rating/score

@router.post("/log")
def log_event(body: LogEvent, db: Session = Depends(get_db), user=Depends(get_current_user)):
    db.add(Interaction(user_id=user.id, product_id=body.product_id, event=body.event, value=body.value))
    db.commit()
    return {"ok": True}