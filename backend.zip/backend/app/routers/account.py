# app/routers/account.py
# app/routers/account.py

from datetime import date, datetime, time
from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.db import get_db

from app.core.security import get_current_user
from app.models import models
from app.schemas.user import (
    UserProfileResponse,
    UserProfileUpdate,
    RecentOrder,
)

router = APIRouter(prefix="/api/account", tags=["account"])


# -------------------------------------------------------------------
# Helper: build RecentOrder list from DB rows
# -------------------------------------------------------------------
def _build_recent_orders(db: Session, user_id: int) -> List[RecentOrder]:
    # load the last 5 orders for this user, newest first
    orders = (
        db.query(models.Order)
        .filter(models.Order.user_id == user_id)
        .order_by(models.Order.created_at.desc())  # NOTE: created_at exists in your table
        .limit(5)
        .all()
    )

    if not orders:
        return []

    order_ids = [o.id for o in orders]

    # pre-load all items for these orders
    items = (
        db.query(models.OrderItem)
        .filter(models.OrderItem.order_id.in_(order_ids))
        .all()
    )
    items_by_order: dict[int, list[models.OrderItem]] = {}
    for it in items:
        items_by_order.setdefault(it.order_id, []).append(it)

    recent: List[RecentOrder] = []

    for o in orders:
        its = items_by_order.get(o.id, [])
        item_count = sum(i.qty for i in its) if its else 0
        total_amount = o.final_total if o.final_total is not None else o.total or 0.0

        recent.append(
            RecentOrder(
                id=o.id,
                order_id=str(o.id),
                total_amount=float(total_amount),
                status=o.status,
                order_date=o.created_at.date(),   # map created_at -> order_date
                item_count=item_count,
                tracking_number=None,             # you don't have this column; keep None
            )
        )

    return recent


# -------------------------------------------------------------------
# GET /api/account/me  → full profile + recent orders
# -------------------------------------------------------------------
@router.get("/me", response_model=UserProfileResponse)
def get_my_profile(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
) -> UserProfileResponse:
    u = current_user

    recent_orders = _build_recent_orders(db, u.id)

    # convert date_of_birth (DateTime in DB) to date in schema
    dob: date | None = None
    if u.date_of_birth:
        if isinstance(u.date_of_birth, datetime):
            dob = u.date_of_birth.date()
        elif isinstance(u.date_of_birth, date):
            dob = u.date_of_birth

    return UserProfileResponse(
        id=u.id,
        username=u.username,
        full_name=getattr(u, "full_name", None),
        email=u.email,
        phone=getattr(u, "phone", None),
        date_of_birth=dob,
        gender=getattr(u, "gender", None),
        fav_color=getattr(u, "fav_color", None),
        skin_tone=getattr(u, "skin_tone", None),
        body_shape=getattr(u, "body_shape", None),
        preferred_fit=getattr(u, "preferred_fit", None),
        style_vibe=getattr(u, "style_vibe", None),
        street_address=getattr(u, "street_address", None),
        city=getattr(u, "city", None),
        postal_code=getattr(u, "postal_code", None),
        country=getattr(u, "country", None),
        profile_picture=getattr(u, "profile_picture", None),
        recent_orders=recent_orders,
    )


# -------------------------------------------------------------------
# PUT /api/account/me  → update profile fields
# -------------------------------------------------------------------
@router.put("/me", response_model=UserProfileResponse)
def update_my_profile(
    payload: UserProfileUpdate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
) -> UserProfileResponse:
    u = current_user

    data = payload.model_dump(exclude_unset=True)

    # handle date_of_birth specially (schema uses date, DB uses DateTime)
    if "date_of_birth" in data and data["date_of_birth"] is not None:
        dob = data["date_of_birth"]
        if isinstance(dob, date) and not isinstance(dob, datetime):
            data["date_of_birth"] = datetime.combine(dob, time.min)

    # apply all provided fields
    for field, value in data.items():
        if hasattr(u, field):
            setattr(u, field, value)

    db.commit()
    db.refresh(u)

    # return fresh profile with recent orders
    return get_my_profile(db=db, current_user=u)
