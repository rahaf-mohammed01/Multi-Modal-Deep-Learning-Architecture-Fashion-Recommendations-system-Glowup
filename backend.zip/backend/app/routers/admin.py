# app/routers/admin.py
from fastapi import APIRouter, Body, Depends, Query, UploadFile, File, HTTPException
from pydantic import BaseModel, EmailStr
from sqlalchemy import func, or_
from sqlalchemy.orm import Session
import csv, io, os, uuid, shutil
from app.core.db import get_db
from app.core.deps import require_any_role
from app.core.config import settings
from app.core.security import hash_password
from app.models.models import Product, User, Order
import datetime as dt
import uuid

router = APIRouter(
    prefix="/api/admin",
    tags=["admin"],
    dependencies=[Depends(require_any_role("admin", "supplier"))]
)

class StatusBody(BaseModel):
    status: str


class UserCreate(BaseModel):
    username: str
    email: EmailStr
    password: str
    role: str = "customer"

@router.post("/ingest-csv")
async def ingest_csv(file: UploadFile = File(...), db: Session = Depends(get_db)):
    if not file.filename.lower().endswith(".csv"):
        raise HTTPException(400, "CSV only")
    data = (await file.read()).decode("utf-8", errors="ignore")
    reader = csv.DictReader(io.StringIO(data))
    created = 0
    for row in reader:
        sku_val = (row.get("sku") or "").strip()
        if not sku_val:
            sku_val = f"CSV-{uuid.uuid4().hex[:8].upper()}"
        p = Product(
            sku=sku_val,
            name=row.get("name", ""),
            description=row.get("description", ""),
            category=row.get("category", ""),
            price=float(row.get("price", 0) or 0),
            image_url=row.get("image_url", ""),
            brand=row.get("brand", ""),
            color=row.get("color", ""),
            size=row.get("size", ""),
            in_stock=True,
            # optional extended fields if present in CSV
            stock=int(row.get("stock", 0) or 0),
            available_colors=row.get("available_colors", ""),
            available_sizes=row.get("available_sizes", "XS,S,M,L,XL"),
        )
        db.add(p)
        created += 1
    db.commit()
    return {"created": created}

@router.get("/products/search")
def search_products(
    q: str = Query("", description="Name contains"),
    category: str = Query("", description="Exact category filter"),
    db: Session = Depends(get_db),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
):
    qset = db.query(Product)
    if q:
        qset = qset.filter(Product.name.ilike(f"%{q}%"))
    if category:
        qset = qset.filter(Product.category == category)
    items = (qset.order_by(Product.id.desc())
                  .offset(offset).limit(limit).all())
    return {"items": items}

@router.post("/pricing")
def set_pricing(
    name: str = Body(...),
    category: str = Body(""),
    new_price: float = Body(...),
    db: Session = Depends(get_db),
):
    q = db.query(Product).filter(Product.name == name)
    if category:
        q = q.filter(Product.category == category)
    p = q.first()
    if not p:
        raise HTTPException(404, "Product not found")
    p.price = new_price
    db.commit()
    db.refresh(p)
    return {"ok": True, "product": p}

@router.post("/inventory")
def set_inventory(
    name: str = Body(...),
    category: str = Body(""),
    new_stock: int = Body(...),
    db: Session = Depends(get_db),
):
    q = db.query(Product).filter(Product.name == name)
    if category:
        q = q.filter(Product.category == category)
    p = q.first()
    if not p:
        raise HTTPException(404, "Product not found")
    p.stock = new_stock
    db.commit()
    db.refresh(p)
    return {"ok": True, "product": p}

# Optional: update a product's image URL after /uploads/image
@router.post("/products/{pid}/image")
def set_product_image(pid: int, file: UploadFile = File(...), db: Session = Depends(get_db)):
    p = db.get(Product, pid)
    if not p:
        raise HTTPException(404, "Not found")

    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
    ext = os.path.splitext(file.filename)[1].lower()
    path = os.path.join(settings.UPLOAD_DIR, f"{uuid.uuid4().hex}{ext}")
    with open(path, "wb") as f:
        shutil.copyfileobj(file.file, f)

    p.image_url = path
    db.commit()
    db.refresh(p)
    return {"ok": True, "image_url": p.image_url}


@router.get("/users")
def list_users(db: Session = Depends(get_db)):
    items = db.query(User).filter(User.role != "admin").order_by(User.id.desc()).all()
    return {"items": items}

@router.post("/users")
def add_user(body: UserCreate, db: Session = Depends(get_db)):
    if db.query(User).filter(or_(User.email == body.email, User.username == body.username)).first():
        raise HTTPException(400, "Email or username already exists")
    u = User(email=body.email, username=body.username,
             password_hash=hash_password(body.password), role=body.role)
    db.add(u); db.commit(); db.refresh(u)
    return u

@router.post("/users/{uid}/status")
def set_user_status(uid: int, body: StatusBody, db: Session = Depends(get_db)):
    u = db.get(User, uid)
    if not u: raise HTTPException(404, "User not found")
    u.status = body.status
    db.commit(); db.refresh(u)
    return u

@router.delete("/users/{uid}")
def delete_user(uid: int, db: Session = Depends(get_db)):
    u = db.get(User, uid)
    if not u: raise HTTPException(404, "User not found")
    db.delete(u); db.commit()
    return {"ok": True}

@router.get("/orders")
def list_orders(db: Session = Depends(get_db)):
    items = db.query(Order).order_by(Order.id.desc()).all()
    return {"items": items}

@router.post("/orders/{oid}/status")
def set_order_status(oid: int, body: StatusBody, db: Session = Depends(get_db)):
    o = db.get(Order, oid)
    if not o: raise HTTPException(404, "Order not found")
    o.status = body.status
    db.commit(); db.refresh(o)
    return o

@router.post("/orders/{oid}/refund")
def refund_order(oid: int, db: Session = Depends(get_db)):
    o = db.get(Order, oid)
    if not o: raise HTTPException(404, "Order not found")
    o.status = "refunded"
    o.refund_date = dt.datetime.utcnow()
    db.commit(); db.refresh(o)
    return {"id": o.id, "status": o.status,
            "refund_date": o.refund_date.isoformat() if o.refund_date else None}

@router.get("/stats")
def stats(db: Session = Depends(get_db)):
    return {
        "products": db.query(func.count(Product.id)).scalar(),
        "users": db.query(func.count(User.id)).scalar(),
        "orders": db.query(func.count(Order.id)).scalar(),
        "low_stock": db.query(Product).filter(Product.stock <= 10).count(),
    }

@router.get("/inventory/low")
def low_stock(db: Session = Depends(get_db)):
    items = db.query(Product).filter(Product.stock <= 10).order_by(Product.stock.asc()).all()
    return {"items": items}

@router.put("/products/{pid}")
def admin_update_product(
    pid: int,
    payload: dict = Body(...),
    db: Session = Depends(get_db),
):
    """
    Generic admin update for a product (used for soft delete / hide).
    Example body: {"in_stock": false, "stock": 0}
    """
    p = db.get(Product, pid)
    if not p:
        raise HTTPException(status_code=404, detail="Product not found")

    for key, value in payload.items():
        if hasattr(p, key):
            setattr(p, key, value)

    db.commit()
    db.refresh(p)
    return {"ok": True, "product": p}
