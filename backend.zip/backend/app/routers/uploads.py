# app/routers/uploads.py

from fastapi import APIRouter, UploadFile, File, HTTPException
from app.core.config import settings
from pathlib import Path
import uuid, shutil

router = APIRouter(prefix="/api/uploads", tags=["uploads"])

@router.post("/image")
async def upload_image(file: UploadFile = File(...)):
    upload_dir = Path(settings.UPLOAD_DIR)
    upload_dir.mkdir(parents=True, exist_ok=True)

    ext = Path(file.filename).suffix.lower()
    if ext not in {".jpg", ".jpeg", ".png", ".gif", ".webp"}:
        raise HTTPException(status_code=400, detail="Unsupported file type")

    new_name = f"{uuid.uuid4().hex}{ext}"
    save_path = upload_dir / new_name

    with save_path.open("wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    # URL that frontend can store/use
    url = f"/media/{new_name}"
    return {"url": url, "filename": new_name}
