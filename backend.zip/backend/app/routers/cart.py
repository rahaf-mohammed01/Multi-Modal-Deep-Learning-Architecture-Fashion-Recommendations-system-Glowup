from fastapi import APIRouter, Body, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.core.deps import get_current_user
from app.models.models import CartItem, Product, Order, OrderItem
from app.schemas.cart import CartAdd, CheckoutForm

router = APIRouter(prefix="/api/cart", tags=["cart"])

TAX_RATE = 0.15

def _compute_totals(db: Session, user_id: int):
    items = db.query(CartItem).filter(CartItem.user_id == user_id).all()
    result = []
    subtotal = 0.0
    for it in items:
        p = db.get(Product, it.product_id)
        if not p:
            continue
        st = round(p.price * it.qty, 2)
        subtotal = round(subtotal + st, 2)
        # include chosen variant on the line item
        result.append({
            "id": it.id,
            "product": p,
            "qty": it.qty,
            "color": it.color,
            "size": it.size,
            "subtotal": st
        })
    tax = round(subtotal * TAX_RATE, 2)
    total = round(subtotal + tax, 2)
    return result, {"subtotal": subtotal, "tax": tax, "total": total}

@router.get("")
def get_cart(db: Session = Depends(get_db), user=Depends(get_current_user)):
    items, summary = _compute_totals(db, user.id)
    return {"items": items, "total": summary["subtotal"], "summary": summary}

@router.post("/add")
def add_item(body: CartAdd, db: Session = Depends(get_db), user=Depends(get_current_user)):
    p = db.get(Product, body.product_id)
    if not p:
        raise HTTPException(404, "Product not found")

    # combine by product+color+size so variants are separate lines
    ci = (
        db.query(CartItem)
          .filter_by(user_id=user.id, product_id=p.id, color=body.color, size=body.size)
          .first()
    )
    if ci:
        ci.qty += max(1, body.qty)
    else:
        ci = CartItem(
            user_id=user.id,
            product_id=p.id,
            qty=max(1, body.qty),
            color=body.color,
            size=body.size
        )
        db.add(ci)
    db.commit(); db.refresh(ci)
    return {"id": ci.id, "qty": ci.qty, "color": ci.color, "size": ci.size}

@router.post("/update/{cid}")
def update_qty(cid: int, qty: int = Body(..., embed=True), db: Session = Depends(get_db), user=Depends(get_current_user)):
    if qty < 1: qty = 1
    ci = db.get(CartItem, cid)
    if not ci or ci.user_id != user.id:
        raise HTTPException(404, "Not found")
    ci.qty = qty
    db.commit()
    items, summary = _compute_totals(db, user.id)
    return {"ok": True, "summary": summary}

@router.post("/remove/{cid}")
def remove_item(cid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    ci = db.get(CartItem, cid)
    if not ci or ci.user_id != user.id:
        raise HTTPException(404, "Not found")
    db.delete(ci); db.commit()
    items, summary = _compute_totals(db, user.id)
    return {"ok": True, "summary": summary}

@router.post("/checkout")
def checkout(payload: CheckoutForm | None = None, db: Session = Depends(get_db), user=Depends(get_current_user)):
    cart_items = db.query(CartItem).filter(CartItem.user_id == user.id).all()
    if not cart_items:
        raise HTTPException(400, "Cart empty")

    # compute totals first
    items, summary = _compute_totals(db, user.id)

    # create order, save items (including variant), clear cart
    order = Order(
        user_id=user.id,
        total=summary["subtotal"],
        tax=summary["tax"],
        final_total=summary["total"],
        buyer_name=(payload.name if payload and payload.name else ""),
        buyer_email=(payload.email if payload and payload.email else ""),
        buyer_phone=(payload.phone if payload and payload.phone else ""),
        buyer_address=(payload.address if payload and payload.address else ""),
        payment_method=(payload.payment_method if payload and payload.payment_method else "card"),
        status="processing" if (payload and payload.payment_method != "cash") else "confirmed"
    )
    db.add(order); db.flush()

    for it in cart_items:
        p = db.get(Product, it.product_id)
        if not p:
            continue
        db.add(OrderItem(
            order_id=order.id,
            product_id=p.id,
            price=p.price,
            qty=it.qty,
            color=it.color,
            size=it.size
        ))
        db.delete(it)

    db.commit(); db.refresh(order)

    # return shape that FE expects
    return {
        "id": order.id,
        "total": summary["subtotal"],
        "tax": summary["tax"],
        "final_total": summary["total"],
        "buyer_name": order.buyer_name,
        "buyer_email": order.buyer_email,
        "payment_method": order.payment_method,
        "address": order.buyer_address,
        "phone": order.buyer_phone,
        "status": order.status
    }
