from fastapi import APIRouter
from pydantic import BaseModel
import os
import logging
from dotenv import load_dotenv
import openai

# Load environment variables
load_dotenv()


from app.ml.chatbot_kaggle import get_chatbot

# Read API key securely from .env
openai.api_key = os.getenv("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")

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/chat", tags=["chat"])

# Request from Angular
class ChatRequest(BaseModel):
    user_id: int | None = None
    message: str


# Response to Angular
class ChatResponse(BaseModel):
    reply: str


# single shared chatbot instance
chatbot = get_chatbot()


@router.post("/ask", response_model=ChatResponse)
async def ask(req: ChatRequest) -> ChatResponse:
    """
    GlowUP FAQ chatbot (Kaggle-based).
    """
    bot = get_chatbot()  # lazy: only loads when first request comes
    reply = bot.answer(req.message)
    return ChatResponse(reply=reply)