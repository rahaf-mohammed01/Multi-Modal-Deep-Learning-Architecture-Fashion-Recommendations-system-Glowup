# app/routers/reco.py

from typing import List, Dict, Any

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.core.deps import get_db           # same style as account router
from app.core.security import get_current_user
from app.models import models
from app.services.reco import RecoEngine

# router for recommendation endpoints
router = APIRouter(prefix="/api/reco", tags=["reco"])

# single global engine (loads embeddings once)
reco_engine = RecoEngine()


# helper: convert Product -> small card dict for frontend
def _product_to_card(p: models.Product, score: float | None = None) -> Dict[str, Any]:
    return {
        "id": p.id,
        "sku": p.sku,
        "name": p.name,
        "image_url": p.image_url,
        "category": p.category,
        "price": p.price,
        "color": p.color,
        "size": p.size,
        "brand": p.brand,
        # optional fields used by the UI
        "score": score,
        "reason": None,
        "tags": [],
    }


# ---------- For You: personalized product feed ----------

@router.get("/for-you")
def get_for_you(
    limit: int = Query(12, ge=1, le=50),
    db: Session = Depends(get_db),
    user: models.User = Depends(get_current_user),
):
    """
    Return a list of personalized product cards for the logged-in user.
    """
    # use AI engine to get list of products (or (product, score))
    recs = reco_engine.personalized_for_user(db=db, user_id=user.id, k=limit)

    out: List[Dict[str, Any]] = []
    for r in recs:
        # support both formats: Product or (Product, score)
        if isinstance(r, tuple):
            prod, score = r
        else:
            prod, score = r, None
        out.append(_product_to_card(prod, score))

    return out


# ---------- Outfit recommender: full-look suggestions ----------

@router.get("/outfits")
def get_outfits(
    k: int = Query(5, ge=1, le=10),
    db: Session = Depends(get_db),
    user: models.User = Depends(get_current_user),
):
    """
    Return K outfits. Each outfit is a list of items (tops, bottoms, etc.).
    """
    # engine returns: List[List[Product]]
    looks: List[List[models.Product]] = reco_engine.generate_outfits(
        db=db,
        user_id=user.id,
        k=k,
    )

    if not looks:
        # no outfits found (e.g., not enough products)
        return []

    outfits: List[Dict[str, Any]] = []
    for idx, look in enumerate(looks, start=1):
        items = [_product_to_card(p) for p in look]

        outfits.append(
            {
                "id": f"look-{idx}",
                "title": f"Look {idx}",
                "score": None,  # you can later compute a score in RecoEngine
                "items": items,
                "explanation": "AI-generated outfit based on your style and catalog.",
            }
        )

    return outfits
