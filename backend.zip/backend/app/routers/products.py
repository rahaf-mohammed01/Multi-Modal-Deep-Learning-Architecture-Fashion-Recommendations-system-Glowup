from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional
from app.core.db import get_db
from app.core.deps import get_current_user, require_any_role
from app.models.models import Product
from app.schemas.product import ProductIn, ProductUpdate
from secrets import token_hex


router = APIRouter(prefix="/api/products", tags=["products"])

@router.get("")
def list_products(db: Session = Depends(get_db), q: Optional[str] = None, category: Optional[str] = None,
                  brand: Optional[str] = None, limit: int = Query(24, ge=1, le=100), offset: int = Query(0, ge=0)):
    qset = db.query(Product)
    if q:
        q_like = f"%{q}%"
        qset = qset.filter(Product.name.ilike(q_like))
    if category:
        qset = qset.filter(Product.category == category)
    if brand:
        qset = qset.filter(Product.brand == brand)
    total = qset.count()
    items = qset.order_by(Product.id).offset(offset).limit(limit).all()
    return {"total": total, "items": items}


@router.get("/{pid}")
def get_product(pid: int, db: Session = Depends(get_db)):
    p = db.query(Product).get(pid)
    if not p:
        raise HTTPException(404, "Product not found")
    return p

@router.post("", dependencies=[Depends(require_any_role("admin"))])
def create_product(body: ProductIn, db: Session = Depends(get_db)):
    data = body.model_dump()
    # generate SKU if blank
    if not data.get("sku"):
        sku = f"SKU-{token_hex(4).upper()}"
        while db.query(Product).filter_by(sku=sku).first():
            sku = f"SKU-{token_hex(4).upper()}"
        data["sku"] = sku
    # infer in_stock from stock if provided
    if "stock" in data:
        data["in_stock"] = bool(data["stock"] > 0)
    p = Product(**data)
    db.add(p); db.commit(); db.refresh(p)
    return p

@router.put("/{pid}", dependencies=[Depends(require_any_role("admin"))])
def update_product(pid: int, body: ProductUpdate, db: Session = Depends(get_db)):
    p = db.get(Product, pid)
    if not p: raise HTTPException(404, "Not found")
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(p, k, v)
    db.commit(); db.refresh(p)
    return p

@router.delete("/{pid}")
def delete_product(pid: int, db: Session = Depends(get_db)):
    p = db.get(Product, pid)
    if not p:
        raise HTTPException(status_code=404, detail="Product not found")

    try:
        db.delete(p)
        db.commit()
        return {"ok": True, "mode": "hard"}
    except Exception:
        # Optional: if FK constraints block deletion, tell frontend to soft-delete
        db.rollback()
        raise HTTPException(status_code=409, detail="Product is referenced by other records")

@router.put("/{pid}")
def update_product(pid: int, body: dict, db: Session = Depends(get_db)):
    p = db.get(Product, pid)
    if not p:
        raise HTTPException(status_code=404, detail="Product not found")
    for k, v in body.items():
        if hasattr(p, k):
            setattr(p, k, v)
    db.commit()
    db.refresh(p)
    return p

