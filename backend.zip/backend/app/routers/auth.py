from fastapi import APIRouter, Body, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import or_ 
from app.core.db import get_db
from app.core.security import hash_password, verify_password, create_access_token, create_refresh_token
from app.models.models import PasswordResetToken, User
from app.schemas.auth import RegisterRequest, LoginRequest, TokenResponse
import secrets, datetime as dt


router = APIRouter(prefix="/api/auth", tags=["auth"])

@router.post("/register")
def register(req: RegisterRequest, db: Session = Depends(get_db)):
    if db.query(User).filter(or_(User.email == req.email, User.username == req.username)).first():
        raise HTTPException(400, "Email or username already registered")
    u = User(
        email=req.email,
        username=req.username,                     
        password_hash=hash_password(req.password),
        role=req.role
    )
    db.add(u); db.commit(); db.refresh(u)
    return {"id": u.id, "email": u.email, "username": u.username, "role": u.role}

@router.post("/login", response_model=TokenResponse)
def login(req: LoginRequest, db: Session = Depends(get_db)):
    if not req.email and not req.username:
        raise HTTPException(400, "email or username is required")
    u = db.query(User).filter(
        or_(User.email == req.email, User.username == req.username)
    ).first()
    if not u or not verify_password(req.password, u.password_hash):
        raise HTTPException(401, "Invalid credentials")
    return TokenResponse(
        access_token=create_access_token(str(u.id)),
        refresh_token=create_refresh_token(str(u.id)),
        role=u.role,
        username=u.username or "",                # 👈 include username in token response
    )

@router.post("/request-reset")
def request_reset(email: str = Body(..., embed=True), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == email).first()
    # Always act like it's fine (don't leak existence)
    token = secrets.token_hex(16)
    if user:
        prt = PasswordResetToken(
            user_id=user.id,
            token=token,
            expires_at=dt.datetime.utcnow() + dt.timedelta(hours=1),
            used=False,
        )
        db.add(prt); db.commit()
    # In a real system, email the link. For dev, return token for convenience.
    return {"ok": True, "dev_token": token}

@router.post("/reset-password")
def reset_password(token: str = Body(...), new_password: str = Body(...), db: Session = Depends(get_db)):
    prt = db.query(PasswordResetToken).filter(
        PasswordResetToken.token == token,
        PasswordResetToken.used == False,
        PasswordResetToken.expires_at > dt.datetime.utcnow()
    ).first()
    if not prt:
        raise HTTPException(400, "Invalid or expired token")
    user = db.get(User, prt.user_id)
    user.password_hash = hash_password(new_password)
    prt.used = True
    db.commit()
    return {"ok": True}