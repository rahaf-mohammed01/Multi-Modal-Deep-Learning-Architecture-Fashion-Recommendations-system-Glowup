from typing import Optional
from pydantic import BaseModel

class ProductIn(BaseModel):
    sku: Optional[str] = None           # was: str
    name: str
    description: str
    category: str
    price: float
    image_url: str = ""                 # give safe defaults
    brand: str = ""
    color: str = ""
    size: str = ""
    in_stock: bool = True
    available_colors: str = ""
    available_sizes:  str = "XS,S,M,L,XL"
    stock:            int = 0

class ProductOut(ProductIn):
    id: int

class ProductUpdate(BaseModel):
    sku: Optional[str] = None
    name: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    price: Optional[float] = None
    image_url: Optional[str] = None
    brand: Optional[str] = None
    color: Optional[str] = None
    size: Optional[str] = None
    in_stock: Optional[bool] = None
    available_colors: Optional[str] = None
    available_sizes: Optional[str] = None
    stock: Optional[int] = None
