# app/routers/reco.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import Dict, List

from app.core.security import get_current_user
from app.db import get_db
from app.services.reco import RecoEngine
from app.models.models import User, Product

router = APIRouter(prefix="/api/reco", tags=["Recommendations"])

# global engine
reco_engine = RecoEngine()

# -----------------------------------------------------
# GET /api/reco/for-you
# -----------------------------------------------------
@router.get("/for-you", response_model=List[Dict])
def get_for_you(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not current_user:
        raise HTTPException(status_code=401, detail="Not authenticated")

    # get product IDs recommended for this user
    product_ids = reco_engine.recommend_for_user(db, user_id=current_user.id, k=12)

    # fetch product details
    products = (
        db.query(Product)
        .filter(Product.id.in_(product_ids))
        .all()
    )

    return [
        {
            "id": p.id,
            "name": p.name,
            "price": p.price,
            "image_url": p.image_url,
            "category": p.category,
        }
        for p in products
    ]


# -----------------------------------------------------
# GET /api/reco/outfits
# -----------------------------------------------------
@router.get("/outfits", response_model=Dict[str, Dict])
def get_outfits(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not current_user:
        raise HTTPException(status_code=401, detail="Not authenticated")

    # use the user's last interacted product as anchor
    last = (
        db.query(Product)
        .join(Product.interactions)
        .filter(Product.interactions.any(user_id=current_user.id))
        .order_by(Product.interactions.any().desc())
        .first()
    )

    if not last:
        raise HTTPException(400, "User has no interactions, cannot build outfit.")

    outfit_ids = reco_engine.build_outfit(db, anchor_pid=last.id)

    # fetch full product details
    result = {}
    for part, pid in outfit_ids.items():
        if pid:
            product = db.query(Product).filter(Product.id == pid).first()
            if product:
                result[part] = {
                    "id": product.id,
                    "name": product.name,
                    "category": product.category,
                    "price": product.price,
                    "image_url": product.image_url,
                }
        else:
            result[part] = None

    return result
