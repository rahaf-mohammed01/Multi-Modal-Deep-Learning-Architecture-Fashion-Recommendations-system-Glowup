from pydantic import BaseModel

class CartAdd(BaseModel):
    product_id: int
    qty: int = 1
    color: str | None = None
    size: str | None = None 

class CartQtyUpdate(BaseModel):
    qty: int 

class CheckoutForm(BaseModel):
    name: str | None = None
    email: str | None = None
    payment_method: str | None = None   # e.g. "Card", "Apple pay", "Cash on Delivery"
    address: str | None = None
    phone: str | None = None
