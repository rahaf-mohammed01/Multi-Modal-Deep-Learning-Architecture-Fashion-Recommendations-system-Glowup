from .user import UserProfile, RecentOrder, UserProfileUpdate  # add this line
