from typing import Optional
from pydantic import BaseModel, EmailStr

class RegisterRequest(BaseModel):
    email: EmailStr
    password: str
    role: str = "customer"
    username: str 

class LoginRequest(BaseModel):
    email: EmailStr | None = None          
    username: str | None = None      
    password: str

class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    role: str
    username: str