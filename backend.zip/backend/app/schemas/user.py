# app/schemas/user.py

from datetime import date
from typing import List, Optional

from pydantic import BaseModel, EmailStr


# ---------- Small helper model for recent orders ----------

class RecentOrder(BaseModel):
    id: int
    order_date: date
    total_amount: float
    item_count: int
    status: str
    tracking_number: Optional[str] = None

    class Config:
        orm_mode = True  # pydantic v1 style (just a warning in v2)


# ---------- Base profile fields shared by all profile schemas ----------

class UserProfileBase(BaseModel):
    username: str
    full_name: Optional[str] = None
    email: EmailStr
    phone: Optional[str] = None
    date_of_birth: Optional[date] = None
    gender: Optional[str] = None

    fav_color: Optional[str] = None
    skin_tone: Optional[str] = None
    body_shape: Optional[str] = None
    preferred_fit: Optional[str] = None
    style_vibe: Optional[str] = None

    street_address: Optional[str] = None
    city: Optional[str] = None
    postal_code: Optional[str] = None
    country: Optional[str] = None

    profile_picture: Optional[str] = None


# ---------- Response model returned from /api/account/me ----------

class UserProfileResponse(UserProfileBase):
    id: int
    recent_orders: List[RecentOrder] = []

    class Config:
        orm_mode = True


# Backwards-compat alias (in case some code still imports UserProfile)
class UserProfile(UserProfileResponse):
    pass


# ---------- Model used for PATCH/PUT updates ----------

class UserProfileUpdateRequest(BaseModel):
    # all optional – front-end can send only the fields that changed
    full_name: Optional[str] = None
    phone: Optional[str] = None
    date_of_birth: Optional[date] = None
    gender: Optional[str] = None

    fav_color: Optional[str] = None
    skin_tone: Optional[str] = None
    body_shape: Optional[str] = None
    preferred_fit: Optional[str] = None
    style_vibe: Optional[str] = None

    street_address: Optional[str] = None
    city: Optional[str] = None
    postal_code: Optional[str] = None
    country: Optional[str] = None

    profile_picture: Optional[str] = None


# Backwards-compat alias (if router uses UserProfileUpdate)
UserProfileUpdate = UserProfileUpdateRequest
