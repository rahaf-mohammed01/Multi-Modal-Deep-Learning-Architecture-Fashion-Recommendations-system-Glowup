from pydantic import BaseModel
from typing import List

class OrderItemOut(BaseModel):
    product_id: int
    price: float
    qty: int

class OrderOut(BaseModel):
    id: int
    total: float
    items: List[OrderItemOut]