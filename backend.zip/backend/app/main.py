# backend/app/main.py

from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.core.config import settings
from app.core.db import init_db, SessionLocal

# Routers
from app.routers import (
    auth,
    products,
    reco,
    cart,
    admin,
    uploads,
    account,
    interactions,
    chatbot,
    orders,
)

app = FastAPI(title="GlowUP API")

# --- CORS (relaxed for local dev) ---
app.add_middleware(
    CORSMiddleware,
    allow_origins=getattr(settings, "CORS_ORIGINS", ["*"]),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Include Routers ---
app.include_router(auth.router)
app.include_router(products.router)
app.include_router(reco.router)
app.include_router(cart.router)
app.include_router(admin.router)
app.include_router(uploads.router)
app.include_router(account.router)
app.include_router(interactions.router)
app.include_router(chatbot.router)
app.include_router(orders.router)

# --- Static media for uploaded files (product images, etc.) ---
upload_path = Path(settings.UPLOAD_DIR)
upload_path.mkdir(parents=True, exist_ok=True)
app.mount("/media", StaticFiles(directory=upload_path), name="media")


@app.on_event("startup")
def on_startup() -> None:
    """
    Initialize database and seed default admin user.
    """
    init_db()
    _seed_default_admin()


def _seed_default_admin() -> None:
    """
    Creates a default root admin if it does not exist:
        email:    root@glowup.com
        password: root123@
    """
    from app.models.models import User
    from app.core.security import hash_password

    db = SessionLocal()
    try:
        email = "root@glowup.com"
        user = db.query(User).filter(User.email == email).first()
        if not user:
            admin_user = User(
                email=email,
                username="root",
                password_hash=hash_password("root123@"),
                role="admin",
            )
            db.add(admin_user)
            db.commit()
    finally:
        db.close()
