from __future__ import annotations

from logging.config import fileConfig
from pathlib import Path
import sys

from alembic import context
from sqlalchemy import engine_from_config, pool

# --- Alembic config & logging ---
config = context.config
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# --- Ensure project root is importable ---
ROOT = Path(__file__).resolve().parents[1]  # C:\glowup\backend
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# --- IMPORT YOUR MODELS MODULE (loads all mapped classes) ---
import app.models.models as models
target_metadata = models.Base.metadata

# DEBUG: prove Alembic sees your tables
print(f"ALEMBIC DEBUG: tables at import time = {len(target_metadata.tables)}")
# Optional: print names
# print('ALEMBIC DEBUG:', list(target_metadata.tables.keys()))

def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode."""
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        compare_type=True,
    )
    with context.begin_transaction():
        context.run_migrations()

def run_migrations_online() -> None:
    """Run migrations in 'online' mode."""
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,
        )
        with context.begin_transaction():
            context.run_migrations()

if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
